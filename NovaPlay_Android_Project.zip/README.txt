NOVAPLAY ANDROID STARTER PROJECT
================================

What this is
------------
NovaPlay is a dark gaming-hub Android project. It includes a native Android
WebView shell and a local HTML/CSS/JS interface bundled inside the app.
The search, category filters, navigation, and demo buttons work offline.

Important honesty note
----------------------
This ZIP is source code, NOT a compiled APK. ChatGPT cannot install or compile
an APK directly onto your phone. To produce an APK, the project must be built
using Android SDK/Gradle in a compatible build environment or an Android cloud
build service. This project is not configured with a cloud build service yet.

Project contents
----------------
- app/src/main/java/.../MainActivity.java : Android app entry point
- app/src/main/assets/ : offline app interface
- app/src/main/AndroidManifest.xml : Android app settings
- app/build.gradle and root Gradle files : Android build configuration

Build requirements
------------------
- Android SDK Platform 35
- JDK 17
- Gradle 8.9 or compatible wrapper
- Android Gradle Plugin 8.7.3

Simple build route
------------------
1. Extract this ZIP.
2. Open the project in an Android-compatible build environment that supports
   Android Gradle projects.
3. Let Gradle sync and install the required Android SDK components.
4. Build the debug APK with the Gradle task: :app:assembleDebug
5. The resulting APK is normally at app/build/outputs/apk/debug/app-debug.apk.
6. Transfer that APK to your Android phone and install it. Android may ask you
   to allow installs from the app used to open the APK.

No AIDE or GitHub is needed to edit the source. However, APK compilation still
requires a build environment/service. If you want a no-PC workflow, choose a
cloud Android build service that accepts uploaded project ZIPs; check its
current Android Gradle support and privacy terms before uploading.

Customization
-------------
- Edit game names/categories in app/src/main/assets/index.html.
- Edit colors and layout in app/src/main/assets/style.css.
- Edit filtering and button behavior in app/src/main/assets/app.js.

The PLAY buttons are demo placeholders. They do not install or launch games
until you add a real game URL or native Android launch integration.
